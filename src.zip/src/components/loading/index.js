import React, { Component } from 'react'
import "./index.less"
export default class Loadings extends Component {
    render() {
        return (
            <div className="loader"> Loading... </div>
        )
    }
       
}